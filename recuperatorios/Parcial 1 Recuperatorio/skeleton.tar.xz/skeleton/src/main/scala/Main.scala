import org.json4s._
import org.json4s.jackson.JsonMethods._
import scala.io.Source


object Main {
  // Define `Subscription` as a simple tuple type alias
  type Subscription = (String, String)
  type Post = (String, String)

    // Pure function to read subscriptions from a JSON file
  def readSubscriptions(path: String): List[Subscription] = {
    val source = Source.fromFile(path)
    val jsonString = source.mkString
    implicit val formats: Formats = DefaultFormats

    val json = parse(jsonString)
    val subscriptions = json.extract[List[Map[String, String]]].map { subscriptionMap =>
      (subscriptionMap("name"), subscriptionMap("url"))
    }
    subscriptions
  }

  def readPosts(url: String): List[Option[Post]] = {
    try {
      val source = Source.fromURL(url)
      val jsonContent = source.mkString
      source.close
      implicit val formats: Formats = DefaultFormats

      val json = parse(jsonContent)
      val children = (json \ "data" \ "children").extract[List[JValue]]

      children.map { child =>
        try {
          val data = child \ "data"
          val title = (data \ "title").extract[String]
          val author = (data \ "author").extract[String]
          Some(title, author)
        }
        catch {
          case _: Throwable => None
        }
      }
    }
    catch {
      case _: Throwable => List.empty
    }
  }

  // Main function to run
  def main(args: Array[String]): Unit = {
    val header = s"Reddit Post Parser\n${"=" * 40}"

    val subscriptions: List[Subscription] = readSubscriptions("subscriptions.json")

    var allPosts: List[Post] = List.empty

    for (subscription <- subscriptions) {
      val subscriptionName = subscription._1
      val subscriptionUrl = subscription._2

      println(s"Descargando posts de: $subscriptionName")
      var postsFromSubscription: List[Option[Post]] = readPosts(subscriptionUrl)

      for (post <- postsFromSubscription) {
        post match {
          case None =>
          case Some(post) => {
            allPosts = allPosts :+ post
            println(s"  - ${post._2}: ${post._1}")
          }
        }
      }
    }

    println("=======================")
    println(s"Total de posts descargados: ${allPosts.length}")
    println("=======================")
  }
}
